chrome.runtime.onInstalled.addListener(() => {
  console.log("Layout Inspector Extension installed!");
});
