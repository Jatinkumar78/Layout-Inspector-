if (!window.pesticideStyle) {
  const style = document.createElement("style");
  style.id = "pesticide-style";
  style.textContent = `
      * {
        outline: 1px solid #0000FF !important;
      }
    `;
  document.head.appendChild(style);
  window.pesticideStyle = style;
} else {
  window.pesticideStyle.remove();
  window.pesticideStyle = null;
}
